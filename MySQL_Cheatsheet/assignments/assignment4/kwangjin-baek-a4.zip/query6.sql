USE swexpert;

SELECT COUNT(*) AS skill_id_1_count
FROM consultant_skill
WHERE skill_id = 1;