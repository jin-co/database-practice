USE ex;

UPDATE color_sample SET color_name = 'Green' WHERE color_id = 6;