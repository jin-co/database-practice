USE ex;

INSERT INTO color_sample VALUES(DEFAULT, 783, 'Red');