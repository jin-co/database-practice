USE ex;
SET SQL_SAFE_UPDATES = 0;

DELETE FROM color_sample WHERE color_name IS NULL;